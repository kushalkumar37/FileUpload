The application is developed using Spring Boot framework using Maven build tool.
 
The application can be run from command prompt using maven command "mvn spring-boot:run"
 
Alternatively, It can be imported in to eclipse IDE as Maven Project and run the main Spring Boot application file SpringBootWebApplication.java, this file is located at package com.assignment
 
After running the application using Maven or from Eclipse IDE, we can access the application from browser with URL - "http://localhost:8080/", This loads the home page of the application.

Controller - FileUploadController.java
------------------------------------------
A controller is created to handle the requests, it is located at path - com.assignment.controller.FileUploadController

The controller handles below URL patterns:

To load home page with all uploaded files - http://localhost:8080/ - GET
To load a specific file with given name - http://localhost:8080/file/<file-name-goes-here> - GET
To save a file - http://localhost:8080/ - GET

Service class FileStorageService.java, FileStorageServiceImpl.java
------------------------------------------------------------------
A Service class is created to handle the business logic to save and retrieve the stored files.

The files are stored in directory with name "uploaded-files"

Model class - FileData.java
----------------------------
FileData class is created to store file meta-data details like file name, extension, size, content-type.

Custom exception classes are created in the package com.assignment.exception.

Configuration file - application.properties
---------------------------------------------
This file holds information about maximum file size that can be uploaded, currently the application allows files with size upto 10MB
This also holds details about the location of JSP files

uploadForm.jsp
----------------
This is the JSP file, that helps users to upload a file, see the list of files uploaded with its meta-data, and download a file.

Test Cases:
-----------
FileStorageServiceTests.java is the Unit Test file to test the service class FileStorageServiceImpl.java

